<template>
    <div>
        <div class="a0">
            <img class="img-head" src="012stockphoto_TP_V4.jpg">
        </div>
        <div class="b0">
            <p>好きな季節とその理由<br>暑さと虫が苦手なので、その二つを遠ざけられる冬が好きな季節</p>
        </div>
        <div class="c0">
            <ul>
                <li><a @click='state = "info"' href="#">トップ</a></li>
                <li><a @click='state = "info_01"' href="#">自己紹介</a></li>
                <li><a @click='state = "info_02"' href="#">好きな季節</a></li>
            </ul>
        </div>
    </div>
</template>